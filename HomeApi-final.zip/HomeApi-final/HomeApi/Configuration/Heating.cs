﻿namespace HomeApi.Configuration
{
    /// <summary>
    /// Тип отопления
    /// </summary>
    public enum Heating
    {
        None,
        Oven,
        Gas,
        Electric,
    }
}