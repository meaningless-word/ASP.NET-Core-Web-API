﻿namespace HomeApi.Configuration
{
    /// <summary>
    /// Материал изготовления
    /// </summary>
    public enum Material
    {
        Stone,
        Wood,
        Brick
    }
}